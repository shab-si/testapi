from django.shortcuts import render

# Create your views here.
# views.py
from rest_framework import generics, viewsets, filters
from .models import Article
from .serializers import ArticleSerializer
from .filters import ArticleFilter
from django_filters.rest_framework import DjangoFilterBackend
from django.db.models import Q
from rest_framework.response import Response

def article_search_view(request):
    query = request.GET.get('q')  # دریافت کوئری از پارامتر q در query string
    if query:
        articles = Article.objects.filter(Q(title__icontains=query) | Q(content__icontains=query))
    else:
        articles = Article.objects.all()
    context = {
        'articles': articles,
        'query': query,
    }
    return render(request, 'article_search.html', context)    

class ArticleListCreate(generics.ListCreateAPIView):
    queryset = Article.objects.all()
    serializer_class = ArticleSerializer

class ArticleDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = Article.objects.all()
    serializer_class = ArticleSerializer


from .cachemanager import CacheManager
from django.core.cache import cache
from rest_framework.decorators import action
class ArticleViewSet(viewsets.ModelViewSet):
    queryset = Article.objects.all()
    serializer_class = ArticleSerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter, DjangoFilterBackend]
    filterset_class = ArticleFilter  # اضافه کردن فیلترهای مخصوص
    search_fields = ['title', 'content']  # جستجو در این فیلدها
    #from cache
    lookup_field = 'id'
    cache_manager = CacheManager()

    def retrieve(self, request, *args, **kwargs):
        article_id = kwargs.get('id')
        #cache_key = f'article_{article_id}'
        #cached_article = cache.get(cache_key)
        cached_article = self.cache_manager.get_cached_data('article', article_id)
        
        if cached_article:
            article = cached_article
        else:
            article = self.get_object()
            self.cache_manager.set_cached_data('article', article_id, article)

        serializer = self.get_serializer(article)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def search_by_title(self, request):
        title = request.query_params.get('title')
        if not title:
            return Response({"error": "Title parameter is required"}, status=400)
        
        cached_articles = self.cache_manager.get_cached_data('article_search', title)
        
        if cached_articles:
            articles = cached_articles
        else:
            articles = Article.objects.filter(title__icontains=title)
            self.cache_manager.set_cached_data('article_search', title, articles)

        serializer = self.get_serializer(articles, many=True)
        return Response(serializer.data)

