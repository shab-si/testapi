from django.urls import path, include
from . import views
from .views import ArticleListCreate, ArticleDetail, ArticleViewSet
from drf_spectacular.views import SpectacularAPIView, SpectacularRedocView, SpectacularSwaggerView
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register(r'articles/filters', ArticleViewSet, basename='article')

urlpatterns = [
    path('articles/', ArticleListCreate.as_view(), name='article-list-create'),
    path('articles/<int:pk>', ArticleDetail.as_view(), name='atricle-detail'),
    path('articles/search/', views.article_search_view, name='article_search_view'),
    #path('articles/filters/', ArticleViewSet.as_view(), name='ArticleViewSet'),
    path('', include(router.urls)),

    # start auto document   
    path('articles/schema/', SpectacularAPIView.as_view(), name='schema'),
    path('articles/schema/swagger-ui/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path('articles/schema/redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
    # end auto document
]