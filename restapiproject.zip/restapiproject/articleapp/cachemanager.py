from django.core.cache import cache
class CacheManager:
    def __init__(self, timeout=60*15):  # زمان انقضا 15 دقیقه
        self.timeout = timeout

    def get_cache_key(self, prefix, identifier):
        return f"{prefix}_{identifier}"

    def get_cached_data(self, prefix, identifier):
        cache_key = self.get_cache_key(prefix, identifier)
        return cache.get(cache_key)

    def set_cached_data(self, prefix, identifier, data):
        cache_key = self.get_cache_key(prefix, identifier)
        cache.set(cache_key, data, timeout=self.timeout)
   
